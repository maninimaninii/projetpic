package com.example.bluet

import android.Manifest
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.pm.PackageManager
import android.graphics.Color
import android.widget.ImageView
import androidx.core.app.ActivityCompat
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import java.io.IOException
import java.io.InputStream
import java.security.KeyStore
import java.util.*

class CourbesBtActivity : AppCompatActivity() {/*
    private lateinit var lineChart: LineChart
    private var xValue = 0f
    private lateinit var bluetoothAdapter: BluetoothAdapter
    private var mmSocket: BluetoothSocket? = null
    private var mmDevice: BluetoothDevice? = null
    private lateinit var mmInputStream: InputStream

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_courbes)

        lineChart = findViewById(R.id.lineChart)

        // Initialisez le BluetoothAdapter

        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()

        // Remplacez l'adresse MAC ci-dessous par celle de votre HC-06
        val deviceAddress = "00:00:00:00:00:00"
        val pairedDevices: Set<BluetoothDevice>? = bluetoothAdapter.bondedDevices
        if (pairedDevices != null) {
            for (device in pairedDevices) {
                if (device.address == deviceAddress) {
                    mmDevice = device
                    break
                }
            }
        }

        // Vérifiez si le périphérique est trouvé
        if (mmDevice == null) {
            // Périphérique non trouvé, affichez un message d'erreur ou une action appropriée
            return
        }

        // Connectez-vous au périphérique Bluetooth
        ConnectThread().start()

        val closeButton: ImageView = findViewById(R.id.closeButton)
        closeButton.setOnClickListener {
            // Fermez la connexion Bluetooth
            try {
                mmSocket?.close()
            } catch (e: IOException) {
                e.printStackTrace()
            }
            finish()
        }

        val entries = List<Entry>
        val dataSet = LineDataSet(entries, "Distances récupérées")
        dataSet.color = Color.parseColor("#FF4081")
        dataSet.valueTextColor = Color.BLACK

        val lineData = LineData(dataSet)
        lineChart.data = lineData

        lineChart.description.isEnabled = false
        lineChart.setBackgroundColor(Color.WHITE)
        lineChart.animateX(1000)
    }

    private inner class ConnectThread : Thread() {
        override fun run() {
            if (ActivityCompat.checkSelfPermission(
                    this,
                    Manifest.permission.BLUETOOTH_SCAN
                ) != PackageManager.PERMISSION_GRANTED
            ) {

                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                return
            }
            bluetoothAdapter.cancelDiscovery()
            try {
                mmSocket = mmDevice?.createRfcommSocketToServiceRecord(UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"))
                mmSocket?.connect()
                mmInputStream = mmSocket!!.inputStream
                while (true) {
                    val buffer = ByteArray(1024)
                    val bytes: Int = mmInputStream.read(buffer)
                    val readMessage = String(buffer, 0, bytes)
                    val data = readMessage.toFloat()
                    runOnUiThread {
                        addEntry(data)
                    }
                    Thread.sleep(1000) // delais
                }
            } catch (e: IOException) {
                // Handle errors
                e.printStackTrace()
            } catch (e: InterruptedException) {
                e.printStackTrace()
            }
        }
    }

    private fun addEntry(data: Float) {
        val dataSet = lineChart.data.getDataSetByIndex(0)

        if (dataSet != null) {
            // Add a new entry with increasing x value
            xValue++
            val entry = Entry(xValue, data)
            dataSet.addEntry(entry)

            // Notify the chart that the data has changed
            lineChart.data.notifyDataChanged()
            lineChart.notifyDataSetChanged()

            // Limit the number of visible entries on the chart
            lineChart.setVisibleXRangeMaximum(10f) // Adjust this based on your requirements

            // Move the chart to the latest entry
            lineChart.moveViewToX(xValue)
        }
    }*/
}
