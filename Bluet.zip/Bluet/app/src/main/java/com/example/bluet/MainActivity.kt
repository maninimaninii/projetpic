package com.example.bluet

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.example.bluet.CourbesActivity
import com.example.bluet.BarresActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<View>(R.id.btn_courbes).setOnClickListener {
            startActivity(Intent(this, CourbesActivity::class.java))
        }

        findViewById<View>(R.id.btn_barres).setOnClickListener {
            startActivity(Intent(this, BarresActivity::class.java))
        }

        findViewById<View>(R.id.btn_courbesbt).setOnClickListener {
            startActivity(Intent(this, CourbesBtActivity::class.java))
        }
    }
}
