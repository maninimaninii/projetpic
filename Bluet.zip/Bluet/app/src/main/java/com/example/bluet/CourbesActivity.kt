package com.example.bluet

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import java.io.BufferedReader
import java.io.InputStreamReader

class CourbesActivity : AppCompatActivity() {
    private lateinit var lineChart: LineChart
    private var xValue = 0f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_courbes)

        lineChart = findViewById(R.id.lineChart)

        val closeButton: ImageView = findViewById(R.id.closeButton)
        closeButton.setOnClickListener {
            finish() // Fermer l'activité lorsque l'utilisateur clique sur la croix
        }

        val entries = arrayListOf<Entry>()
        val dataSet = LineDataSet(entries, "Distances récupérées")
        dataSet.color = Color.BLUE
        dataSet.valueTextColor = Color.BLACK

        val lineData = LineData(dataSet)
        lineChart.data = lineData

        lineChart.description.isEnabled = false
        lineChart.setBackgroundColor(Color.WHITE)
        lineChart.animateX(1000)
        startDataUpdateThread()
    }

    private fun startDataUpdateThread() {
        Thread(Runnable {
            val inputStream = assets.open("data.txt")
            val reader = BufferedReader(InputStreamReader(inputStream))
            var line: String?
            while (reader.readLine().also { line = it } != null) {
                val data = line!!.toFloat()
                runOnUiThread {
                    addEntry(data)
                }
                try {
                    Thread.sleep(1000) // delais
                } catch (e: InterruptedException) {
                    e.printStackTrace()
                }
            }
            reader.close()
        }).start()
    }

    private fun addEntry(data: Float) {
        val dataSet = lineChart.data.getDataSetByIndex(0)

        if (dataSet != null) {
            // Add a new entry with increasing x value
            xValue++
            val entry = Entry(xValue, data)
            dataSet.addEntry(entry)

            // Notify the chart that the data has changed
            lineChart.data.notifyDataChanged()
            lineChart.notifyDataSetChanged()

            // Limit the number of visible entries on the chart
            lineChart.setVisibleXRangeMaximum(10f) // Adjust this based on your requirements

            // Move the chart to the latest entry
            lineChart.moveViewToX(xValue)
        }
    }
}