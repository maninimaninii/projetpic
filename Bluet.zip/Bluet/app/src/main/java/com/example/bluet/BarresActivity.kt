package com.example.bluet

import android.graphics.Color
import android.os.Bundle
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.data.BarEntry
import com.github.mikephil.charting.data.BarDataSet
import com.github.mikephil.charting.data.BarData
import java.io.BufferedReader
import java.io.InputStreamReader

class BarresActivity : AppCompatActivity() {

    private lateinit var barChart: BarChart
    private var xValue = 0f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_barres)

        barChart = findViewById(R.id.barChart)

        val closeButton: ImageView = findViewById(R.id.closeButton)
        closeButton.setOnClickListener {
            finish() // Fermer l'activité lorsque l'utilisateur clique sur la croix
        }

        val entries = arrayListOf<BarEntry>()
        val dataSet = BarDataSet(entries, "Distances récupérées")
        dataSet.color = Color.parseColor("#FF4081")
        dataSet.valueTextColor = Color.BLACK

        val barData = BarData(dataSet)
        barChart.data = barData

        barChart.description.isEnabled = false
        barChart.setBackgroundColor(Color.WHITE)
        barChart.animateX(1000)
        startDataUpdateThread()
    }

    private fun startDataUpdateThread() {
        Thread(Runnable {
            val inputStream = assets.open("data.txt")
            val reader = BufferedReader(InputStreamReader(inputStream))
            var line: String?
            while (reader.readLine().also { line = it } != null) {
                val data = line!!.toFloat()
                runOnUiThread {
                    addEntry(data)
                }
                try {
                    Thread.sleep(1000) // delais
                } catch (e: InterruptedException) {
                    e.printStackTrace()
                }
            }
            reader.close()
        }).start()
    }

    private fun addEntry(data: Float) {
        val dataSet = barChart.data.getDataSetByIndex(0)

        if (dataSet != null) {
            // Add a new entry with increasing x value
            xValue++
            val entry = BarEntry(xValue, data)
            dataSet.addEntry(entry)

            // Notify the chart that the data has changed
            barChart.data.notifyDataChanged()
            barChart.notifyDataSetChanged()

            // Limit the number of visible entries on the chart
            barChart.setVisibleXRangeMaximum(10f) // Adjust this based on your requirements

            // Move the chart to the latest entry
            barChart.moveViewToX(xValue)
        }
    }
}