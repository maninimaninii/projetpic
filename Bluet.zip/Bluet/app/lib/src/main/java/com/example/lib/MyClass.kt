package com.example.lib

class MyClass {
}